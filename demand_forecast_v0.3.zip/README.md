# nodeJSSimpleExpress

Simple NodeJS starting point using the Express framework to server a static HTML file and handle requests (form input), returning a response as JSON
