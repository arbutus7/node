// outline fix with margin for scatter graph
var margin = { top: 30, right: 700, bottom: 50, left: 50 },
  outerWidth = 1250,
  outerHeight = 500,
  width = outerWidth - margin.left - margin.right,
  height = outerHeight - margin.top - margin.bottom;
//outline fix with margin for line graph
var	margin2 = {top: 150, right: 20, bottom: 30, left: 700},
  width2 = 300,
  height2 = 280;

// Define the axis
var x = d3.scale.linear()
    .range([0, width]).nice();
var y = d3.scale.linear()
    .range([height, 0]).nice();

var x2 = d3.scale.linear()
    .range([0, width2]).nice();

var y2 = d3.scale.linear()
        .range([height2, 0]).nice();

var rCat = "Protein (g)",
    colorCat = "Manufacturer";

d3.csv("data_chmber.csv", function(data) {
  data.forEach(function(d) {
    d.xdata = +d.asd;
    d.ydata = +d.aror;
    d.xdata_2 = +d.asd_2;
    d.ydata_2 = +d.aror_2;
    d.xdata_3 = +d.asd_3;
    d.ydata_3 = +d.aror_3;
    // for line graph
    d.xdata_l = +d.asd;
    d.ydata_l = +d.aror;
    d["Protein (g)"] = +d["Protein (g)"];

  });
  var selectData = [ { "text" : "1" },
                      { "text" : "2" },
                      { "text" : "3" },
                    ]

  chamber = 1;
  document.getElementById("3").value = chamber;//input에 값을 넣는다
  var xCat = "xdata",
      yCat = "ydata";

  var xMax = d3.max(data, function(d) { return d[xCat]; }) * 1.05,
      xMin = d3.min(data, function(d) { return d[xCat]; }),
     //xMin = xMin > 0 ? 0 : xMin,
      yMax = d3.max(data, function(d) { return d[yCat]; }) * 1.05,
      yMin = d3.min(data, function(d) { return d[yCat]; });
     //yMin = yMin > 0 ? 0 : yMin;

  x.domain([xMin, xMax]);
  y.domain([yMin, yMax]);
  x2.domain([xMin, xMax]);
  y2.domain([yMin, yMax]);

  var xAxis = d3.svg.axis()
      .scale(x)
      .orient("bottom")
      .tickSize(-height);

  var yAxis = d3.svg.axis()
      .scale(y)
      .orient("left")
      .tickSize(-width);

  var xAxis2 = d3.svg.axis()
      .scale(x2)
      .orient("bottom")
      .tickSize(-height2);

  var yAxis2 = d3.svg.axis()
      .scale(y2)
      .orient("left")
      .tickSize(-width2);

  var color = d3.scale.category10();

// pop up window for displaying the position(x,y)
  var tip = d3.tip()
      .attr("class", "d3-tip")
      .offset([200, 0])
      .html(function(d) {
        return xCat + ": " + (d[xCat]) + "<br>" + yCat + ": " + d[yCat];
      })
  // for zoom
  var zoomBeh = d3.behavior.zoom()
      .x(x)
      .y(y)
      .scaleExtent([0, 500])
      .on("zoom", zoom);

  var svg = d3.select("#scatter")
    .append("svg")
      .attr("width", outerWidth)
      .attr("height", outerHeight)
    .append("g")
      .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
      .call(zoomBeh);

  svg.call(tip);

  svg.append("rect")
      .attr("width", width)
      .attr("height", height);

  svg.append("g")
      .classed("x axis", true)
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis)
    .append("text")
      .classed("label", true)
      .attr("x", width)
      .attr("y", margin.bottom - 10)
      .style("text-anchor", "end")
      .text(xCat);

  svg.append("g")
      .classed("y axis", true)
      .call(yAxis)
    .append("text")
      .classed("label", true)
      .attr("transform", "rotate(-90)")
      .attr("y", -margin.left)
      .attr("dy", ".71em")
      .style("text-anchor", "end")
      .text(yCat);

  var objects = svg.append("svg")
      .classed("objects", true)
      .attr("width", width)
      .attr("height", height);

  objects.append("svg:line")
      .classed("axisLine hAxisLine", true)
      .attr("x1", 0)
      .attr("y1", 0)
      .attr("x2", width)
      .attr("y2", 0)
      .attr("transform", "translate(0," + height + ")");

  objects.append("svg:line")
      .classed("axisLine vAxisLine", true)
      .attr("x1", 0)
      .attr("y1", 0)
      .attr("x2", 0)
      .attr("y2", height);

 // mouse click event for display of position(x,y)
  svg.on("click", function() {
                            var coords = d3.mouse(this);
                            // Normally we go from data to pixels, but here we're doing pixels to data
                            var newData= {
                              x:( x.invert(coords[0])),  // Takes the pixel number to convert to number
                              y:( y.invert(coords[1]))
                            };
                            console.log(newData);
                            svg.append("text")
                            .attr("x", coords[0])
                            .attr("y", coords[1])
                            .style("font-size", "10px")
                            .style("font-family","Arial, Helvetica, sans-serif")
                            .style('font-weight', 'bold')
                            .style('text-color', '#525252')
                            .text(function(d) { return newData.x.toFixed(8) +   ", " + newData.y.toFixed(7); })
                            //please remove followng line to show the text continuslly.
                            .transition()
                            .delay(1000)
                            .remove();
                })

  objects.selectAll(".dot")
      .data(data)
    .enter().append("circle")
      .classed("dot", true)
      .attr("r", function (d) { return 2 * Math.sqrt(d[rCat] / Math.PI); })
      .attr("transform", transform)
      .style("fill", function(d) { return color(d[colorCat]); })
      .on("mouseover", tip.show)
      .on("mouseout", tip.hide)
      .on('click', function(d){
  document.getElementById("1").value = d[xCat];//input에 값을 넣는다
	document.getElementById("2").value = d[yCat];//input에 값을 넣는다

});

// user buttion handling
  d3.select("input[name=chamber1]").on("click", change1);
  d3.select("input[name=chamber2]").on("click", change2);
  d3.select("input[name=chamber3]").on("click", change3);
  d3.select("select[name=chm]").on("change", chageLangSelect);

  function display() {
    var xMax = d3.max(data, function(d) { return d[xCat]; }) * 1.05,
        xMin = d3.min(data, function(d) { return d[xCat]; }),
        //xMin = xMin > 0 ? 0 : xMin,
        yMax = d3.max(data, function(d) { return d[yCat]; }) * 1.05,
        yMin = d3.min(data, function(d) { return d[yCat]; });
        //yMin = yMin > 0 ? 0 : yMin;

    x.domain([xMin, xMax]);
    y.domain([yMin, yMax]);

    zoomBeh.x(x.domain([xMin, xMax])).y(y.domain([yMin, yMax]));

    var svg = d3.select("#scatter").transition();

    svg.select(".x.axis").duration(750).call(xAxis).select(".label").text(xCat);
    svg.select(".y.axis").duration(750).call(yAxis).select(".label").text(yCat);

    objects.selectAll(".dot").transition().duration(1000).attr("transform", transform);
  }

  function change1() {
    xCat = "xdata";
    yCat = "ydata";
    chamber = 1;
    display();
    document.getElementById("3").value = chamber;//input에 값을 넣는다
  }

  function change2() {
    xCat = "xdata_2";
    yCat = "ydata_2";
    chamber = 2;
    display();
    document.getElementById("3").value = chamber;//input에 값을 넣는다
  }

  function change3() {
    xCat = "xdata_3";
    yCat = "ydata_3";
    chamber = 3;
    display();
    document.getElementById("3").value = chamber;//input에 값을 넣는다
  }

  function chageLangSelect(){
      var langSelect = document.getElementById("id-lang");
      // select element에서 선택된 option의 value가 저장된다.
      var selectValue = langSelect.options[langSelect.selectedIndex].value;
      // select element에서 선택된 option의 text가 저장된다.
      //var selectText = langSelect.options[langSelect.selectedIndex].text;
      if(selectValue == "chamber1"){
        change1();
      }
      if(selectValue == "chamber2"){
        change2();
      }
      if(selectValue == "chamber3"){
        change3();
      }
  }
  /////////////////////////////////// for line graph
  var	valueline = d3.svg.line()
  .x(function(d) { return x2(d.xdata_l); })
  .y(function(d) { return y2(d.ydata_l); });

  var	chart2 = d3.select("svg")
  	.append("svg")
  		.attr("width", width2 + margin2.left + margin2.right)
  		.attr("height", height2 + margin2.top + margin2.bottom)
  	.append("g")
  		.attr("transform", "translate(" + margin2.left + "," + margin2.top + ")");
  	// Add the valueline path.
  	chart2.append("path")
  		.attr("class", "line")
  		.attr("d", valueline(data));
  	// Add the X Axis
  	chart2.append("g")
  		.attr("class", "x axis")
  		.attr("transform", "translate(0," + height2 + ")")
  		.call(xAxis2);
  	// Add the Y Axis
  	chart2.append("g")
  		.attr("class", "y axis")
  		.call(yAxis2);
///////////////////////////////////// for line graph
  function zoom() {
    svg.select(".x.axis").call(xAxis);
    svg.select(".y.axis").call(yAxis);
    svg.selectAll(".dot")
        .attr("transform", transform2);
  }
  function transform(d) {
    return "translate("+ x(d[xCat]) + "," + y(d[yCat]) + ")";
}
  function transform2(d) {
  return "translate("+ x(d[xCat]) + "," + y(d[yCat]) + ")scale(" + d3.event.scale + ")";
}
});
