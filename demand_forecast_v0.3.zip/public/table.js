function handleFileSelect3(evt) {
  var filename3 = evt.target.files[0];
  console.log(filename3.name);

  var body = d3.select("body");
  var p = body.append("p")
  .attr("style", "margin-left: 200px" )
  .style("font-size", "1.25em")
  .text("Customer table");


var tabulate = function (data,columns) {
  var table = d3.select('body').append('table')
      .attr("style", "margin-left: 200px")

	var thead = table.append('thead')
	var tbody = table.append('tbody')

	thead.append('tr')
	  .selectAll('th')
	    .data(columns)
	    .enter()
	  .append('th')
	    .text(function (d) { return d })

	var rows = tbody.selectAll('tr')
	    .data(data)
	    .enter()
	  .append('tr')

	var cells = rows.selectAll('td')
	    .data(function(row) {
	    	return columns.map(function (column) {
	    		return { column: column, value: row[column] }
	      })
      })
      .enter()
    .append('td')
		.style("border", "1px black solid")
		.style("padding", "5px")
		.style("text-align", "center")
		.on("mouseover", function(){ d3.select(this).style("background-color", "aliceblue")})
		.on("mouseout", function(){ d3.select(this).style("background-color", "white")})
		.style("font-size", "12px")
		.text(function (d) { return d.value })
  return table;
}

d3.csv(filename3.name,function (data) {
	var columns = ['variable','aror','asd','maxdd']
  tabulate(data,columns)
})

}
document.getElementById("file_input3").addEventListener('change', handleFileSelect3, false);
