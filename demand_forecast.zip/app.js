var express = require('express');
var app = express();
var {PythonShell} =require( 'python-shell');
var  pyshell = new PythonShell('my_script.py');



var data='null';

app.use(express.static('public'))

app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');

})

app.get('/python', function(req, res){
  response = {
    first_name:req.query.first_name,
    last_name:req.query.last_name
  };
	var data= [req.query.first_name,req.query.last_name];
	//var data2= req.query.last_name;
	//var filename="signal2.png";


// sends a message to the Python script via stdin

	pyshell.send(data);

	res.write('<h1> python result is </h1>');
// received a message sent from the Python script (a simple "print" statement)
pyshell.on('message', function (message) {

  //console.log(message);

    res.write('<div><p> ' + message + '</p></div>');


});
	function test(){
	var filename1="signal1.png";
	var filename2="signal2.png";
	var filename3="signal3.png";

	res.write("<br><a href='/'>back to the main</a><br>");
	res.write("<img src='"+filename1+"'><br>");
	res.write("<img src='"+filename2+"'><br>");
	res.write("<img src='"+filename3+"'><br>");
}
	setTimeout(test,3000);



  console.log(response);

  //res.end(JSON.stringify(response));
// end the input stream and allow the process to exit
//	pyshell.end(function (err,code,signal) {
//		if (err) throw err;
//		});

})



var server = app.listen(8081, function(){
  var host = server.address().address
  var port = server.address().port
  console.log('Anomaly detection  on http://%s %s', host, port)
})
