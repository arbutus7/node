import sys
print(text)
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import cgi
msg = sys.stdin.readline()

print(msg)
a,b = msg.split(",")

if __name__ == "__main__" :
#def main(x, y):
    filename = "./data/data_chmber0.csv"
    df = pd.read_csv(filename)

    x_value = float(a)
    y_value = float(b)

    df_chosen = df[(round(df['x'], 6) == round(x_value, 6)) & (round(df['y'], 6) == round(y_value, 6))]

    if df_chosen['x'].nunique() == 1 & df_chosen['y'].nunique() == 1:
        signal1 = df_chosen['signal1']
        signal2 = df_chosen['signal2']
        signal3 = df_chosen['signal3']

        plt.clf()
        plt.plot(signal1)
        plt.title('Signal 1')
        plt.savefig('./public/signal1.png')

        plt.clf()
        plt.plot(signal2)
        plt.title('Signal 2')
        plt.savefig('./public/signal2.png')

        plt.clf()
        plt.plot(signal3)
        plt.title('Signal 3')
        plt.savefig('./public/signal3.png')


#if __name__ == "__main__" :
#    main(sys.argv[1], sys.argv[2])
