import sys
import cgi
msg = sys.stdin.readline()

print(msg)
a,b = msg.split(",")
print(a)
print(b)
print ('python code was executing!!')
