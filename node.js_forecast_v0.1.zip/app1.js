var express = require('express');
var app = express();
var router = express.Router();
var {PythonShell} =require( 'python-shell');
//var  pyshell = new PythonShell('signal_chmber1.py');
var data='null';

app.use(express.static('public'))
app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');

})
app.get('/python', function(req, res){
  response = {
    first_name:req.query.first_name,
    last_name:req.query.last_name,
    chmber_name:req.query.chmber_name
  };
	var data= [req.query.first_name,req.query.last_name];
  var number=req.query.chmber_name;

// sends a message to the Python script via stdin

if(number === '1') {
  var  pyshell = new PythonShell('signal_chmber1.py');
}
if(number === '2') {
  var  pyshell = new PythonShell('signal_chmber2.py');
}
if(number === '3') {
  var  pyshell = new PythonShell('signal_chmber3.py');
}

	pyshell.send(data);

	res.write('<h1> python result is </h1>');
// received a message sent from the Python script (a simple "print" statement)
  pyshell.on('message', function (message) {

  console.log(message);

});
	function test(){
	var filename1="signal1.png";
	var filename2="signal2.png";
	var filename3="signal3.png";

	res.write("<br><a href='/'>back to the main</a><br>");
	res.write("<img src='"+filename1+"'><br>");
	res.write("<img src='"+filename2+"'><br>");
	res.write("<img src='"+filename3+"'><br>");
  res.end();
}
	setTimeout(test,3000);

  console.log(res);
  pyshell.end(function (err) {
     if (err){
        throw err;
  };

     });

});//app.get('/python')

var server = app.listen(8081, function(){
  var host = server.address().address
  var port = server.address().port
  console.log('Demand Forecast  on http://%s %s', host, port)
})
