


var margin = { top: 50, right: 700, bottom: 50, left: 50 },
  outerWidth = 1250,
  outerHeight = 500,
  width = outerWidth - margin.left - margin.right,
  height = outerHeight - margin.top - margin.bottom;

var	margin2 = {top: 150, right: 20, bottom: 30, left: 700},

  //width2 = 400 - margin2.left - margin2.right,
  //height2 = 300 - margin2.top - margin2.bottom;
  width2 = 300,
  height2 = 280;

  // Define the axes



var x = d3.scale.linear()
    .range([0, width]).nice();

var y = d3.scale.linear()
    .range([height, 0]).nice();

var x2 = d3.scale.linear()
    .range([0, width2]).nice();

var y2 = d3.scale.linear()
        .range([height2, 0]).nice();


var xCat = "xdata",
    yCat = "ydata",
    rCat = "Protein (g)",
    colorCat = "Manufacturer";







d3.csv("data.csv", function(data) {
  data.forEach(function(d) {
    d.xdata = +d.asd;
    d.ydata = +d.aror;

    d.xdata_m = +d.asd_m;
    d.ydata_m = +d.aror_m;

    // for line graph
    d.xdata_l = +d.asd_l;
    d.ydata_l = +d.aror_l;


    d["Protein (g)"] = +d["Protein (g)"];

  });


  var xMax = d3.max(data, function(d) { return d[xCat]; }) * 1.05,
      xMin = d3.min(data, function(d) { return d[xCat]; }),
      xMin = xMin > 0 ? 0 : xMin,
      yMax = d3.max(data, function(d) { return d[yCat]; }) * 1.05,
      yMin = d3.min(data, function(d) { return d[yCat]; }),
      yMin = yMin > 0 ? 0 : yMin;

  x.domain([xMin, xMax]);
  y.domain([yMin, yMax]);

  x2.domain([xMin, xMax]);
  y2.domain([yMin, yMax]);


  var xAxis = d3.svg.axis()
      .scale(x)
      .orient("bottom")
      .tickSize(-height);

  var yAxis = d3.svg.axis()
      .scale(y)
      .orient("left")
      .tickSize(-width);

  var xAxis2 = d3.svg.axis()
      .scale(x2)
      .orient("bottom")
      .tickSize(-height2);

  var yAxis2 = d3.svg.axis()
      .scale(y2)
      .orient("left")
      .tickSize(-width2);


  var color = d3.scale.category10();

  var tip = d3.tip()
      .attr("class", "d3-tip")
      .offset([-10, 0])
      .html(function(d) {
        return xCat + ": " + d[xCat] + "<br>" + yCat + ": " + d[yCat];
      });



  var zoomBeh = d3.behavior.zoom()
      .x(x)
      .y(y)
      .scaleExtent([0, 500])
      .on("zoom", zoom);

  var svg = d3.select("#scatter")
    .append("svg")
      .attr("width", outerWidth)
      .attr("height", outerHeight)
    //  .attr("width", width+50)
    //  .attr("height", height+50)
    .append("g")
      .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
      .call(zoomBeh);





  svg.call(tip);


  svg.append("rect")
      .attr("width", width)
      .attr("height", height);

  svg.append("g")
      .classed("x axis", true)
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis)
    .append("text")
      .classed("label", true)
      .attr("x", width)
      .attr("y", margin.bottom - 10)
      .style("text-anchor", "end")
      .text(xCat);

  svg.append("g")
      .classed("y axis", true)
      .call(yAxis)
    .append("text")
      .classed("label", true)
      .attr("transform", "rotate(-90)")
      .attr("y", -margin.left)
      .attr("dy", ".71em")
      .style("text-anchor", "end")
      .text(yCat);

// for line graph
//  svg.append("path")
//     .attr("class", "line")
//      .attr("d", valueline(data));


  var objects = svg.append("svg")
      .classed("objects", true)
      .attr("width", width)
      .attr("height", height);

  objects.append("svg:line")
      .classed("axisLine hAxisLine", true)
      .attr("x1", 0)
      .attr("y1", 0)
      .attr("x2", width)
      .attr("y2", 0)
      .attr("transform", "translate(0," + height + ")");

  objects.append("svg:line")
      .classed("axisLine vAxisLine", true)
      .attr("x1", 0)
      .attr("y1", 0)
      .attr("x2", 0)
      .attr("y2", height);



 //mouse click event for display of position(x,y)
  svg.on("click", function() {

                            var coords = d3.mouse(this);

                            // Normally we go from data to pixels, but here we're doing pixels to data
                            var newData= {
                              x:( x.invert(coords[0])),  // Takes the pixel number to convert to number
                              y:( y.invert(coords[1]))
                            };
                            console.log(newData);

                            //svg.append("circle")
                            //  .attr("r",1)
                            //  .attr('stroke','black')
                            //  .attr('stroke-width',0.5)
                            //  .attr('cx', coords[0])
                            //  .attr('cy', coords[1])
                            //  .attr('fill','yellow')

                            svg.append("text")

                            .attr("x", coords[0])
                            .attr("y", coords[1])
                            .style("font-size", "10px")
                            .style("font-family","Arial, Helvetica, sans-serif")
                            .style('font-weight', 'bold')
                            .style('text-color', '#525252')
                            .text(function(d) { return newData.x.toFixed(3) +   ", " + newData.y.toFixed(3); })
                            //please remove followng line to show the text continuslly.
                            .transition()
                            .delay(1000)
                            .remove();
// sends a message to the Python script via stdin
//pyshell.send('hello!!!');

//pyshell.on('message', function (message) {
  // received a message sent from the Python script (a simple "print" statement)
//  console.log(message);
//});
 
                            text ="xx";

$.ajax({
type: "POST",
url: "my_script.py",
data: { param: text}
}).done(function(o) {
    console.log(data);
    console.log(text);
});



                })

//  objects.selectAll(".line")
//      .data(data)
//    .enter().append("path")
//      .classed("line", true)
//      .attr("d", valueline(data))


  objects.selectAll(".dot")
      .data(data)
    .enter().append("circle")
      .classed("dot", true)
      .attr("r", function (d) { return 3 * Math.sqrt(d[rCat] / Math.PI); })
      //.attr("r", 1)
      .attr("transform", transform)
      //.style("fill", 'blue')
      .style("fill", function(d) { return color(d[colorCat]); })
      .on("mouseover", tip.show)
      .on("mouseout", tip.hide);




//////////////////////////////////////////////////////
//var legend = svg.selectAll(".legend")
//      .data(color.domain())
//    .enter().append("g")
//      .classed("legend", true)
//      .attr("transform", function(d, i) { return "translate(0," + i * 20 + ")"; });

//  legend.append("circle")
//     .attr("r", 3)
//      .attr("cx", width + 20)


// legend.append("text")
//      .attr("x", width + 35)
//     .attr("dy", ".35em")
//      .text(function(d) { return d; });

// Adds the svg canvas
// define the line graph

var	valueline = d3.svg.line()
.x(function(d) { return x2(d.xdata_l); })
.y(function(d) { return y2(d.ydata_l); });

var	chart2 = d3.select("svg")
	.append("svg")
		.attr("width", width2 + margin2.left + margin2.right)
		.attr("height", height2 + margin2.top + margin2.bottom)
	.append("g")
		.attr("transform", "translate(" + margin2.left + "," + margin2.top + ")");



	// Scale the range of the data
//	x2.domain(d3.extent(data, function(d) { return d.xdata; }));
//	y2.domain([0, d3.max(data, function(d) { return d.ydata; })]);

	// Add the valueline path.
	chart2.append("path")
		.attr("class", "line")
		.attr("d", valueline(data));

	// Add the X Axis
	chart2.append("g")
		.attr("class", "x axis")
		.attr("transform", "translate(0," + height2 + ")")
		.call(xAxis2);

	// Add the Y Axis
	chart2.append("g")
		.attr("class", "y axis")
		.call(yAxis2);

// user buttion handling
  d3.select("input[name=Month]").on("click", change);
  d3.select("input[name=General]").on("click", back);
  d3.select("input[name=linegraph]").on("click", display);





  function change() {
    xCat = "xdata_m";
    yCat = "ydata_m";
    var xMax = d3.max(data, function(d) { return d[xCat]; }) * 1.05,
        xMin = d3.min(data, function(d) { return d[xCat]; }),
        xMin = xMin > 0 ? 0 : xMin,
        yMax = d3.max(data, function(d) { return d[yCat]; }) * 1.05,
        yMin = d3.min(data, function(d) { return d[yCat]; }),
        yMin = yMin > 0 ? 0 : yMin;

    x.domain([xMin, xMax]);
    y.domain([yMin, yMax]);

    zoomBeh.x(x.domain([xMin, xMax])).y(y.domain([yMin, yMax]));

    var svg = d3.select("#scatter").transition();

    svg.select(".x.axis").duration(750).call(xAxis).select(".label").text(xCat);
    svg.select(".y.axis").duration(750).call(yAxis).select(".label").text(yCat);

    objects.selectAll(".dot").transition().duration(1000).attr("transform", transform);
  }

  function back() {
    xCat = "xdata";
    yCat = "ydata";

    var xMax = d3.max(data, function(d) { return d[xCat]; }) * 1.05,
        xMin = d3.min(data, function(d) { return d[xCat]; }),
        xMin = xMin > 0 ? 0 : xMin,
        yMax = d3.max(data, function(d) { return d[yCat]; }) * 1.05,
        yMin = d3.min(data, function(d) { return d[yCat]; }),
        yMin = yMin > 0 ? 0 : yMin;

    x.domain([xMin, xMax]);
    y.domain([yMin, yMax]);

    zoomBeh.x(x.domain([xMin, xMax])).y(y.domain([yMin, yMax]));

    var svg = d3.select("#scatter").transition();

    svg.select(".x.axis").duration(750).call(xAxis).select(".label").text(xCat);
    svg.select(".y.axis").duration(750).call(yAxis).select(".label").text(yCat);

    objects.selectAll(".dot").transition().duration(1000).attr("transform", transform);
  }

  function zoom() {
    svg.select(".x.axis").call(xAxis);
    svg.select(".y.axis").call(yAxis);

    svg.selectAll(".dot")
        .attr("transform", transform);
  }

  function transform(d) {
    return "translate(" + x(d[xCat]) + "," + y(d[yCat]) + ")";
  }
});
